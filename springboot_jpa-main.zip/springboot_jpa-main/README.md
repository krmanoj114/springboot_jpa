I provide a Medium blog in order to explain this project step by step.

https://justgiveacar.medium.com/spring-boot-micro-services-deployement-on-kubernetes-76c1d298c1f

